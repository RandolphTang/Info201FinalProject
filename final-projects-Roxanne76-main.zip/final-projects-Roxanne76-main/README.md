# Info 201 Data Wrangling  
Info201 Final Project -- Data Wrangling 
Analyze the correlation between university types and income

